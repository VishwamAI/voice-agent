'use strict';
const { App } = require('jovo-framework');
const { Alexa } = require('jovo-platform-alexa');
const { GoogleAssistant } = require('jovo-platform-googleassistant');
const { JovoDebugger } = require('jovo-plugin-debugger');
const { FileDb } = require('jovo-db-filedb');

console.log('This template uses an outdated version of the Jovo Framework. We strongly recommend upgrading to Jovo v4. Learn more here: https://www.jovo.tech/docs/migration-from-v3');

// ------------------------------------------------------------------
// APP INITIALIZATION
// ------------------------------------------------------------------

const app = new App();

app.use(
  new Alexa(),
  new GoogleAssistant(),
  new JovoDebugger(),
  new FileDb()
);

// ------------------------------------------------------------------
// APP LOGIC
// ------------------------------------------------------------------

app.setHandler({
  LAUNCH() {
    console.log('LAUNCH intent triggered');
    return this.toIntent('HelloWorldIntent');
  },

  HelloWorldIntent() {
    console.log('HelloWorldIntent triggered');
    this.ask("Hello, I am Jarvis! What's your name?", 'Please tell me your name.');
  },

  MyNameIsIntent() {
    console.log('MyNameIsIntent triggered with name:', this.$inputs.name ? this.$inputs.name.value : 'undefined');
    this.tell('Hey ' + (this.$inputs.name ? this.$inputs.name.value : 'undefined') + ', nice to meet you!');
  },
});

console.log('App initialization complete');
console.log('App configuration:', app.config);
console.log('App handlers:', app.handlers);

module.exports = { app };
