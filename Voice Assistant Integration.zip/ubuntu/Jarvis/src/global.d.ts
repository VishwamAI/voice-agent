declare module '@jovotech/framework/dist/cjs/metadata/MetadataStorage';
