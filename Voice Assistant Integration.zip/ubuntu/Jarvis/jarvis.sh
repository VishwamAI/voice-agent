#!/bin/bash

# Script to start the Jarvis application
cd /home/ubuntu/Jarvis
node dist/app.dev.js
